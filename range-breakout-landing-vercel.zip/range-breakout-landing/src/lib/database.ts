// Simple in-memory database simulation for demo purposes
// In production, this would be replaced with a real database like PostgreSQL

interface Purchase {
  id: string
  email: string
  name: string
  amount: number
  status: 'pending' | 'completed' | 'failed'
  createdAt: Date
  stripeSessionId?: string
}

interface PresaleStats {
  totalSales: number
  totalRevenue: number
  lastUpdated: Date
}

// In-memory storage (would be replaced with real database)
const purchases: Purchase[] = []

const presaleStats: PresaleStats = {
  totalSales: 347, // Starting with some demo sales
  totalRevenue: 347 * 197, // $197 per sale
  lastUpdated: new Date()
}

export const database = {
  // Get current presale statistics
  getPresaleStats: async (): Promise<PresaleStats> => {
    return presaleStats
  },

  // Add a new purchase
  addPurchase: async (purchase: Omit<Purchase, 'id' | 'createdAt'>): Promise<Purchase> => {
    const newPurchase: Purchase = {
      ...purchase,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date()
    }
    
    purchases.push(newPurchase)
    
    // Update stats if purchase is completed
    if (newPurchase.status === 'completed') {
      presaleStats.totalSales += 1
      presaleStats.totalRevenue += newPurchase.amount
      presaleStats.lastUpdated = new Date()
    }
    
    return newPurchase
  },

  // Update purchase status
  updatePurchaseStatus: async (id: string, status: Purchase['status']): Promise<Purchase | null> => {
    const purchase = purchases.find(p => p.id === id)
    if (!purchase) return null
    
    const oldStatus = purchase.status
    purchase.status = status
    
    // Update stats if status changed to completed
    if (oldStatus !== 'completed' && status === 'completed') {
      presaleStats.totalSales += 1
      presaleStats.totalRevenue += purchase.amount
      presaleStats.lastUpdated = new Date()
    }
    
    return purchase
  },

  // Find purchase by Stripe session ID
  findPurchaseBySessionId: async (sessionId: string): Promise<Purchase | null> => {
    return purchases.find(p => p.stripeSessionId === sessionId) || null
  },

  // Get all purchases for a user
  getUserPurchases: async (email: string): Promise<Purchase[]> => {
    return purchases.filter(p => p.email === email)
  },

  // Check if presale limit is reached
  isPresaleLimitReached: async (): Promise<boolean> => {
    const limit = parseInt(process.env.PRESALE_LIMIT || '500')
    return presaleStats.totalSales >= limit
  },

  // Get remaining presale slots
  getRemainingSlots: async (): Promise<number> => {
    const limit = parseInt(process.env.PRESALE_LIMIT || '500')
    return Math.max(0, limit - presaleStats.totalSales)
  }
}

export type { Purchase, PresaleStats }

