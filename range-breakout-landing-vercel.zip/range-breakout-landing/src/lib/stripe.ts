import Stripe from 'stripe'
import { loadStripe } from '@stripe/stripe-js'

// Server-side Stripe instance
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2025-06-30.basil',
  typescript: true,
})

// Client-side Stripe instance
export const getStripe = () => {
  return loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)
}

// Product configuration
export const PRESALE_PRODUCT = {
  name: 'Range Breakout Pro EA - Presale',
  description: 'Revolutionary MetaTrader 5 Expert Advisor with advanced range breakout strategies',
  price: parseInt(process.env.PRESALE_PRICE || '19700'), // $197.00 in cents
  currency: 'usd',
  images: ['/hero-bg.png'],
  metadata: {
    type: 'presale',
    limit: process.env.PRESALE_LIMIT || '500',
  }
}

