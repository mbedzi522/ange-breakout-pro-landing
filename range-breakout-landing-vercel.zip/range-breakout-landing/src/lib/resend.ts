import { Resend } from 'resend'

export const resend = new Resend(process.env.RESEND_API_KEY)

export const sendWelcomeEmail = async (email: string, name: string) => {
  try {
    const { data, error } = await resend.emails.send({
      from: 'Range Breakout Pro <noreply@rangebreakoutpro.com>',
      to: [email],
      subject: 'Welcome to Range Breakout Pro EA - Your Purchase is Confirmed!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #3b82f6;">Welcome to Range Breakout Pro EA!</h1>
          
          <p>Hi ${name},</p>
          
          <p>Thank you for purchasing Range Breakout Pro EA during our limited presale! Your order has been confirmed and you now have access to:</p>
          
          <ul>
            <li>Range Breakout Pro EA (MT5) file</li>
            <li>Complete installation guide</li>
            <li>Risk management templates</li>
            <li>VIP Telegram group access</li>
            <li>Lifetime free updates</li>
          </ul>
          
          <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #1f2937; margin-top: 0;">Next Steps:</h3>
            <ol>
              <li>Download your EA files from your dashboard</li>
              <li>Follow the installation guide</li>
              <li>Join our VIP Telegram group for support</li>
              <li>Start automated trading!</li>
            </ol>
          </div>
          
          <p>If you have any questions, please don't hesitate to contact our support team.</p>
          
          <p>Happy Trading!<br>
          The Range Breakout Pro Team</p>
          
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #e5e7eb;">
          <p style="font-size: 12px; color: #6b7280;">
            <strong>Risk Warning:</strong> Trading involves substantial risk and may result in loss of capital.
          </p>
        </div>
      `,
    })

    if (error) {
      console.error('Error sending welcome email:', error)
      return { success: false, error }
    }

    return { success: true, data }
  } catch (error) {
    console.error('Error sending welcome email:', error)
    return { success: false, error }
  }
}

export const sendPresaleNotification = async (salesCount: number) => {
  try {
    const { data, error } = await resend.emails.send({
      from: 'Range Breakout Pro <admin@rangebreakoutpro.com>',
      to: ['admin@rangebreakoutpro.com'],
      subject: `New Presale Purchase - ${salesCount}/500 Sold`,
      html: `
        <div style="font-family: Arial, sans-serif;">
          <h2>New Presale Purchase!</h2>
          <p>A new customer has purchased Range Breakout Pro EA.</p>
          <p><strong>Total Sales:</strong> ${salesCount}/500</p>
          <p><strong>Remaining:</strong> ${500 - salesCount} copies</p>
        </div>
      `,
    })

    return { success: true, data }
  } catch (error) {
    console.error('Error sending presale notification:', error)
    return { success: false, error }
  }
}

