import { NextResponse } from 'next/server'
import { database } from '@/lib/database'

export async function GET() {
  try {
    const stats = await database.getPresaleStats()
    const remaining = await database.getRemainingSlots()
    const isLimitReached = await database.isPresaleLimitReached()

    return NextResponse.json({
      totalSales: stats.totalSales,
      totalRevenue: stats.totalRevenue,
      remaining,
      isLimitReached,
      lastUpdated: stats.lastUpdated,
      limit: parseInt(process.env.PRESALE_LIMIT || '500')
    })
  } catch (error) {
    console.error('Error fetching presale stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch presale statistics' },
      { status: 500 }
    )
  }
}

