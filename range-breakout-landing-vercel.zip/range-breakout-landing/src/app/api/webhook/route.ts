import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { database } from '@/lib/database'
import { sendWelcomeEmail, sendPresaleNotification } from '@/lib/resend'
import Stripe from 'stripe'

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = req.headers.get('stripe-signature')

  if (!signature) {
    return NextResponse.json(
      { error: 'No signature provided' },
      { status: 400 }
    )
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (error) {
    console.error('Webhook signature verification failed:', error)
    return NextResponse.json(
      { error: 'Invalid signature' },
      { status: 400 }
    )
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        
        // Find the purchase record
        const purchase = await database.findPurchaseBySessionId(session.id)
        if (!purchase) {
          console.error('Purchase not found for session:', session.id)
          break
        }

        // Update purchase status to completed
        await database.updatePurchaseStatus(purchase.id, 'completed')

        // Send welcome email
        await sendWelcomeEmail(
          session.metadata?.userEmail || purchase.email,
          session.metadata?.userName || purchase.name
        )

        // Send admin notification
        const stats = await database.getPresaleStats()
        await sendPresaleNotification(stats.totalSales)

        console.log('Payment completed for:', session.metadata?.userEmail)
        break
      }

      case 'checkout.session.expired': {
        const session = event.data.object as Stripe.Checkout.Session
        
        // Find and update purchase record
        const purchase = await database.findPurchaseBySessionId(session.id)
        if (purchase) {
          await database.updatePurchaseStatus(purchase.id, 'failed')
        }
        
        console.log('Payment session expired:', session.id)
        break
      }

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('Error processing webhook:', error)
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    )
  }
}

