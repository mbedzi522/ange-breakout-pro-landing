import { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Range Breakout Pro EA - Automated Forex Trading',
    short_name: 'Range Breakout Pro',
    description: 'Revolutionary MetaTrader 5 Expert Advisor with advanced range breakout strategies',
    start_url: '/',
    display: 'standalone',
    background_color: '#0f172a',
    theme_color: '#3b82f6',
    icons: [
      {
        src: '/hero-bg.png',
        sizes: 'any',
        type: 'image/png',
      },
    ],
  }
}

