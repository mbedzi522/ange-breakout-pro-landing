import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import StructuredData from '@/components/structured-data'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Range Breakout Pro EA - Limited Presale | Automated Forex Trading',
  description: 'Revolutionary MetaTrader 5 Expert Advisor with advanced range breakout strategies. Limited presale - only 500 copies available. 78% win rate, automated risk management.',
  keywords: 'forex ea, expert advisor, metatrader 5, automated trading, range breakout, forex robot, trading bot, mt5 ea, forex automation, algorithmic trading',
  authors: [{ name: 'Range Breakout Pro Team' }],
  creator: 'Range Breakout Pro',
  publisher: 'Range Breakout Pro',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://rangebreakoutpro.com'),
  alternates: {
    canonical: '/',
  },
  openGraph: {
    title: 'Range Breakout Pro EA - Limited Presale | Automated Forex Trading',
    description: 'Revolutionary MetaTrader 5 Expert Advisor with 78% win rate. Limited presale - only 500 copies available. Advanced range breakout strategies with automated risk management.',
    type: 'website',
    url: 'https://rangebreakoutpro.com',
    siteName: 'Range Breakout Pro',
    locale: 'en_US',
    images: [
      {
        url: '/hero-bg.png',
        width: 1200,
        height: 630,
        alt: 'Range Breakout Pro EA - Automated Forex Trading',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Range Breakout Pro EA - Limited Presale | Automated Forex Trading',
    description: 'Revolutionary MetaTrader 5 Expert Advisor with 78% win rate. Limited presale - only 500 copies available.',
    images: ['/hero-bg.png'],
    creator: '@RangeBreakoutPro',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
    yandex: 'your-yandex-verification-code',
    yahoo: 'your-yahoo-verification-code',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <StructuredData />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}

