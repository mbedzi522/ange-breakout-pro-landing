'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CheckCircle, Download, Users } from 'lucide-react'
import Link from 'next/link'

function SuccessContent() {
  const searchParams = useSearchParams()
  const [isVerified, setIsVerified] = useState(false)
  const sessionId = searchParams.get('session_id')

  useEffect(() => {
    // In a real app, you would verify the session with your backend
    if (sessionId) {
      setIsVerified(true)
    }
  }, [sessionId])

  if (!isVerified) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Verifying your purchase...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="max-w-4xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            Payment Successful!
          </h1>
          <p className="text-xl text-gray-300 mb-2">
            Welcome to Range Breakout Pro EA, Trader!
          </p>
          <p className="text-gray-400">
            Your purchase has been confirmed and you now have access to all presale benefits.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-blue-400" />
                Download Your EA
              </CardTitle>
              <CardDescription className="text-gray-400">
                Get instant access to your Range Breakout Pro EA files
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Download EA Files
              </Button>
              <p className="text-sm text-gray-400 mt-2">
                Includes: EA file, installation guide, and risk management templates
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" />
                Join VIP Community
              </CardTitle>
              <CardDescription className="text-gray-400">
                Connect with other traders and get exclusive support
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full bg-purple-600 hover:bg-purple-700">
                Join Telegram Group
              </Button>
              <p className="text-sm text-gray-400 mt-2">
                Get trading tips, updates, and direct support from our team
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-gray-900/50 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="text-white">What&apos;s Next?</CardTitle>
            <CardDescription className="text-gray-400">
              Follow these steps to get started with your Range Breakout Pro EA
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  1
                </div>
                <div>
                  <h4 className="font-semibold text-white">Download & Install</h4>
                  <p className="text-gray-400 text-sm">Download the EA file and follow the installation guide for MetaTrader 5</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  2
                </div>
                <div>
                  <h4 className="font-semibold text-white">Configure Settings</h4>
                  <p className="text-gray-400 text-sm">Use our risk management templates to set up optimal trading parameters</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  3
                </div>
                <div>
                  <h4 className="font-semibold text-white">Start Trading</h4>
                  <p className="text-gray-400 text-sm">Begin automated trading and monitor performance through your MT5 platform</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  4
                </div>
                <div>
                  <h4 className="font-semibold text-white">Get Support</h4>
                  <p className="text-gray-400 text-sm">Join our VIP community for ongoing support and trading insights</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <p className="text-gray-400 mb-4">
            A confirmation email has been sent to your email address
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    }>
      <SuccessContent />
    </Suspense>
  )
}

