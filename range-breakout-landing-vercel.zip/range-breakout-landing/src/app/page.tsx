'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import DemoCheckoutButton from '@/components/demo-checkout-button'
import { 
  TrendingUp, 
  Shield, 
  Clock, 
  Star, 
  CheckCircle, 
  ArrowRight,
  Users,
  Award,
  Zap
} from 'lucide-react'

interface PresaleStats {
  totalSales: number
  remaining: number
  isLimitReached: boolean
  limit: number
}

export default function LandingPage() {
  const [presaleStats, setPresaleStats] = useState<PresaleStats>({
    totalSales: 347,
    remaining: 153,
    isLimitReached: false,
    limit: 500
  })
  const [timeLeft, setTimeLeft] = useState({
    days: 7,
    hours: 12,
    minutes: 34,
    seconds: 56
  })

  // Fetch presale stats
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch('/api/presale-stats')
        if (response.ok) {
          const data = await response.json()
          setPresaleStats(data)
        }
      } catch (error) {
        console.error('Error fetching presale stats:', error)
      }
    }

    fetchStats()
    // Refresh stats every 30 seconds
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  // Countdown timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const progressPercentage = (presaleStats.totalSales / presaleStats.limit) * 100

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
          style={{ backgroundImage: 'url(/hero-bg.png)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/50 to-purple-900/50" />
        
        <div className="relative z-10 max-w-6xl mx-auto px-4 text-center">
          <Badge className="mb-6 bg-green-500/20 text-green-400 border-green-500/30">
            <Zap className="w-4 h-4 mr-2" />
            Limited Presale - Only {presaleStats.limit} Copies Available
          </Badge>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Range Breakout Pro EA
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Revolutionary MetaTrader 5 Expert Advisor that automates your Forex trading with advanced range breakout strategies and intelligent risk management
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <DemoCheckoutButton className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg px-8 py-4" />
            <Button size="lg" variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800 text-lg px-8 py-4">
              Watch Demo
            </Button>
          </div>
          
          {/* Sales Progress */}
          <div className="max-w-md mx-auto">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>Copies Sold</span>
              <span>{presaleStats.totalSales}/{presaleStats.limit}</span>
            </div>
            <Progress value={progressPercentage} className="h-3 bg-gray-800" />
            <p className="text-sm text-gray-400 mt-2">
              {presaleStats.isLimitReached ? (
                <span className="text-red-400 font-semibold">SOLD OUT!</span>
              ) : (
                <>Only {presaleStats.remaining} copies remaining!</>
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Countdown Timer */}
      <section className="py-16 bg-gradient-to-r from-red-900/20 to-orange-900/20 border-y border-red-500/20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8 text-red-400">Presale Ends In:</h2>
          <div className="grid grid-cols-4 gap-4 max-w-lg mx-auto">
            {Object.entries(timeLeft).map(([unit, value]) => (
              <div key={unit} className="bg-gray-900/50 rounded-lg p-4 border border-red-500/20">
                <div className="text-3xl font-bold text-red-400">{value.toString().padStart(2, '0')}</div>
                <div className="text-sm text-gray-400 capitalize">{unit}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Why Choose Range Breakout Pro EA?</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Advanced automation meets proven strategy for consistent trading performance
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <TrendingUp className="w-12 h-12 text-blue-400 mb-4" />
                <CardTitle className="text-white">Proven Strategy</CardTitle>
                <CardDescription className="text-gray-400">
                  Advanced range breakout algorithm with 78% win rate over 2+ years of backtesting
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <Shield className="w-12 h-12 text-green-400 mb-4" />
                <CardTitle className="text-white">Risk Management</CardTitle>
                <CardDescription className="text-gray-400">
                  Built-in stop loss, take profit, and position sizing to protect your capital
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="bg-gray-900/50 border-gray-700">
              <CardHeader>
                <Clock className="w-12 h-12 text-purple-400 mb-4" />
                <CardTitle className="text-white">24/7 Trading</CardTitle>
                <CardDescription className="text-gray-400">
                  Automated execution means you never miss a profitable opportunity
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Trusted by Traders Worldwide</h2>
            <div className="flex justify-center items-center gap-8 text-gray-400">
              <div className="flex items-center gap-2">
                <Users className="w-6 h-6" />
                <span>2,500+ Active Users</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-6 h-6 text-yellow-400" />
                <span>4.8/5 Rating</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-6 h-6 text-blue-400" />
                <span>Award Winning</span>
              </div>
            </div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="bg-gray-900/50 border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-300 mb-4">
                    &ldquo;This EA has completely transformed my trading. The automated risk management alone has saved me thousands.&rdquo;
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                      {String.fromCharCode(65 + i)}
                    </div>
                    <div>
                      <div className="font-semibold text-white">Trader {String.fromCharCode(65 + i)}</div>
                      <div className="text-sm text-gray-400">Professional Trader</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-gradient-to-br from-blue-900/20 to-purple-900/20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-8">Limited Time Presale Offer</h2>
          
          <Card className="bg-gray-900/50 border-gray-700 max-w-lg mx-auto">
            <CardHeader>
              <Badge className="w-fit mx-auto mb-4 bg-green-500/20 text-green-400 border-green-500/30">
                Save 60% - Presale Only
              </Badge>
              <CardTitle className="text-3xl text-white">
                <span className="line-through text-gray-500 text-xl mr-2">$497</span>
                $197
              </CardTitle>
              <CardDescription className="text-gray-400">
                One-time payment • Lifetime license • Free updates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                {[
                  'Range Breakout Pro EA (MT5)',
                  'Complete Setup Guide',
                  'Risk Management Templates',
                  'VIP Telegram Group Access',
                  'Lifetime Free Updates',
                  '30-Day Money Back Guarantee'
                ].map((feature) => (
                  <div key={feature} className="flex items-center gap-2 text-gray-300">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
              
              <DemoCheckoutButton className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg py-6">
                Get Instant Access Now (Demo)
                <ArrowRight className="ml-2 w-5 h-5" />
              </DemoCheckoutButton>
              
              <p className="text-sm text-gray-400">
                Secure payment via Stripe • SSL encrypted
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            {[
              {
                q: "What is Range Breakout Pro EA?",
                a: "It's an automated trading system (Expert Advisor) for MetaTrader 5 that uses advanced range breakout strategies to identify and execute profitable trades automatically."
              },
              {
                q: "Do I need trading experience to use this EA?",
                a: "No! The EA is designed for both beginners and experienced traders. It comes with preset configurations and a complete setup guide."
              },
              {
                q: "What's included in the presale?",
                a: "You get the Range Breakout Pro EA file, complete installation guide, risk management templates, VIP community access, and lifetime updates."
              },
              {
                q: "Is there a money-back guarantee?",
                a: "Yes, we offer a 30-day money-back guarantee. If you're not satisfied, we'll refund your purchase."
              },
              {
                q: "How many copies are available?",
                a: "This is a limited presale with only 500 copies available to ensure exclusivity and proper support for all users."
              }
            ].map((faq, index) => (
              <Card key={index} className="bg-gray-900/50 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-white text-lg">{faq.q}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-gray-900 border-t border-gray-800">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-white mb-4">Range Breakout Pro</h3>
              <p className="text-gray-400 text-sm">
                Professional automated trading solutions for MetaTrader 5.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Features</li>
                <li>Pricing</li>
                <li>Documentation</li>
                <li>Support</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Terms of Service</li>
                <li>Privacy Policy</li>
                <li>Refund Policy</li>
                <li>Risk Disclaimer</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>support@rangebreakoutpro.com</li>
                <li>Telegram: @RangeBreakoutPro</li>
                <li>Discord Community</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2025 Range Breakout Pro. All rights reserved.</p>
            <p className="mt-2">
              <strong>Risk Warning:</strong> Trading involves substantial risk and may result in loss of capital.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

