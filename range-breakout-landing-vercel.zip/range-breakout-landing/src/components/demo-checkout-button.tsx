'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowRight, Loader2 } from 'lucide-react'

interface DemoCheckoutButtonProps {
  className?: string
  children?: React.ReactNode
}

export default function DemoCheckoutButton({ className, children }: DemoCheckoutButtonProps) {
  const [isLoading, setIsLoading] = useState(false)

  const handleDemoCheckout = async () => {
    setIsLoading(true)
    
    // Simulate loading
    setTimeout(() => {
      alert('Demo Mode: In production, this would redirect to Stripe Checkout.\n\nTo complete the integration:\n1. Add your Clerk API keys\n2. Add your Stripe API keys\n3. Add your Resend API key\n4. Configure webhooks')
      setIsLoading(false)
    }, 2000)
  }

  return (
    <Button 
      size="lg" 
      className={className}
      onClick={handleDemoCheckout}
      disabled={isLoading}
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 w-5 h-5 animate-spin" />
          Processing...
        </>
      ) : (
        children || (
          <>
            Secure Your Copy Now (Demo)
            <ArrowRight className="ml-2 w-5 h-5" />
          </>
        )
      )}
    </Button>
  )
}

