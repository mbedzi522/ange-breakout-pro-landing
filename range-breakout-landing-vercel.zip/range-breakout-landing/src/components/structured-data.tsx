export default function StructuredData() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Product",
    "name": "Range Breakout Pro EA",
    "description": "Revolutionary MetaTrader 5 Expert Advisor that automates your Forex trading with advanced range breakout strategies and intelligent risk management",
    "brand": {
      "@type": "Brand",
      "name": "Range Breakout Pro"
    },
    "category": "Software > Trading Software > Expert Advisors",
    "image": [
      "https://rangebreakoutpro.com/hero-bg.png"
    ],
    "offers": {
      "@type": "Offer",
      "url": "https://rangebreakoutpro.com",
      "priceCurrency": "USD",
      "price": "197.00",
      "priceValidUntil": "2025-08-31",
      "availability": "https://schema.org/LimitedAvailability",
      "seller": {
        "@type": "Organization",
        "name": "Range Breakout Pro"
      },
      "validFrom": "2025-07-29"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "2500"
    },
    "review": [
      {
        "@type": "Review",
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "5"
        },
        "author": {
          "@type": "Person",
          "name": "Professional Trader"
        },
        "reviewBody": "This EA has completely transformed my trading. The automated risk management alone has saved me thousands."
      }
    ]
  }

  const organizationData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Range Breakout Pro",
    "url": "https://rangebreakoutpro.com",
    "logo": "https://rangebreakoutpro.com/hero-bg.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-555-0123",
      "contactType": "customer service",
      "email": "support@rangebreakoutpro.com"
    },
    "sameAs": [
      "https://t.me/RangeBreakoutPro"
    ]
  }

  const websiteData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "Range Breakout Pro EA",
    "url": "https://rangebreakoutpro.com",
    "description": "Revolutionary MetaTrader 5 Expert Advisor with advanced range breakout strategies",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://rangebreakoutpro.com/?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(structuredData),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(organizationData),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(websiteData),
        }}
      />
    </>
  )
}

