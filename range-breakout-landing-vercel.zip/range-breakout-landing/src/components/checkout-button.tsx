'use client'

import { useState } from 'react'
import { useUser, SignInButton } from '@clerk/nextjs'
import { Button } from '@/components/ui/button'
import { getStripe } from '@/lib/stripe'
import { ArrowRight, Loader2 } from 'lucide-react'

interface CheckoutButtonProps {
  className?: string
  children?: React.ReactNode
}

export default function CheckoutButton({ className, children }: CheckoutButtonProps) {
  const { isSignedIn, user } = useUser()
  const [isLoading, setIsLoading] = useState(false)

  const handleCheckout = async () => {
    if (!isSignedIn) return

    setIsLoading(true)

    try {
      // Create checkout session
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create checkout session')
      }

      // Redirect to Stripe Checkout
      const stripe = await getStripe()
      if (!stripe) {
        throw new Error('Stripe failed to load')
      }

      const { error } = await stripe.redirectToCheckout({
        sessionId: data.sessionId,
      })

      if (error) {
        throw new Error(error.message)
      }
    } catch (error) {
      console.error('Checkout error:', error)
      alert(error instanceof Error ? error.message : 'An error occurred during checkout')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isSignedIn) {
    return (
      <SignInButton mode="modal">
        <Button size="lg" className={className}>
          {children || (
            <>
              Sign In to Purchase
              <ArrowRight className="ml-2 w-5 h-5" />
            </>
          )}
        </Button>
      </SignInButton>
    )
  }

  return (
    <Button 
      size="lg" 
      className={className}
      onClick={handleCheckout}
      disabled={isLoading}
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 w-5 h-5 animate-spin" />
          Processing...
        </>
      ) : (
        children || (
          <>
            Secure Your Copy Now
            <ArrowRight className="ml-2 w-5 h-5" />
          </>
        )
      )}
    </Button>
  )
}

