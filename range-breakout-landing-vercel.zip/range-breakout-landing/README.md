# Range Breakout Pro EA - Landing Page

A modern, high-converting landing page for the Range Breakout Pro Expert Advisor with presale functionality, built with Next.js and optimized for SEO.

## 🚀 Features

- **Presale Functionality**: Limited to 500 copies with real-time progress tracking
- **Countdown Timer**: Creates urgency for the presale offer
- **Payment Integration**: Stripe checkout ready for production
- **User Authentication**: Clerk integration for user management
- **Email Notifications**: Resend integration for automated emails
- **SEO Optimized**: Complete meta tags, structured data, and sitemap
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Modern UI**: Built with Shadcn/UI components

## 🛠️ Tech Stack

- **Framework**: Next.js 15 with TypeScript
- **Styling**: Tailwind CSS + Shadcn/UI
- **Authentication**: Clerk
- **Payments**: Stripe
- **Email**: Resend
- **Database**: PostgreSQL (production ready)
- **Deployment**: Vercel

## 📦 What's Included

### Landing Page Sections
- Hero section with compelling copy
- Real-time sales counter (347/500 sold)
- Presale countdown timer
- Feature highlights
- Customer testimonials
- Pricing section with savings
- FAQ section
- Professional footer

### Technical Features
- Server-side rendering (SSR)
- API routes for payments and data
- Environment variable configuration
- Production-ready build
- SEO optimization
- Performance optimized

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ installed
- npm or yarn package manager

### Local Development
1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy environment variables:
   ```bash
   cp .env.local.example .env.local
   ```
4. Start development server:
   ```bash
   npm run dev
   ```
5. Open http://localhost:3000

### Environment Variables
Create a `.env.local` file with these variables:

```env
# Clerk Authentication
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=your_clerk_publishable_key
CLERK_SECRET_KEY=your_clerk_secret_key

# Stripe Payment Processing
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_webhook_secret

# Resend Email Service
RESEND_API_KEY=your_resend_api_key

# Application Settings
NEXT_PUBLIC_APP_URL=http://localhost:3000
PRESALE_LIMIT=500
PRESALE_PRICE=19700  # $197.00 in cents
REGULAR_PRICE=49700  # $497.00 in cents

# Database (Optional)
DATABASE_URL=your_postgresql_connection_string
```

## 🌐 Deployment

### Deploy to Vercel (Recommended)
1. Push your code to GitHub
2. Connect your GitHub repository to Vercel
3. Configure environment variables in Vercel dashboard
4. Deploy automatically

For detailed deployment instructions, see `vercel-deployment-guide.md`.

### Other Platforms
The application can also be deployed to:
- Netlify
- Railway
- Heroku
- DigitalOcean App Platform

## 🔧 Configuration

### API Services Setup

#### Clerk Authentication
1. Create account at https://clerk.com
2. Create new application
3. Get API keys from dashboard
4. Configure allowed domains

#### Stripe Payments
1. Create account at https://stripe.com
2. Complete business verification
3. Get live API keys
4. Set up webhook endpoints

#### Resend Email
1. Create account at https://resend.com
2. Verify your domain
3. Get API key
4. Configure email templates

### Database Setup (Optional)
For production with real user data:
1. Set up PostgreSQL database (Supabase recommended)
2. Run database migrations
3. Update connection string

## 📊 Analytics & Monitoring

### Built-in Features
- Real-time sales tracking
- Presale progress monitoring
- User engagement metrics

### Recommended Tools
- Google Analytics
- Vercel Analytics
- Sentry for error tracking
- Stripe Dashboard for payments

## 🎨 Customization

### Content Updates
- Edit `/src/app/page.tsx` for main content
- Update `/src/components/structured-data.tsx` for SEO
- Modify `/public/sitemap.xml` for site structure

### Styling Changes
- Update `/src/app/globals.css` for custom styles
- Modify Tailwind classes in components
- Change color scheme in CSS variables

### Adding Features
- Add new API routes in `/src/app/api/`
- Create new components in `/src/components/`
- Extend database schema if needed

## 🔒 Security

- Environment variables for sensitive data
- HTTPS enforced by default
- CSRF protection on API routes
- Input validation and sanitization
- Secure payment processing with Stripe

## 📈 Performance

- Next.js automatic optimization
- Image optimization with Next.js Image
- Code splitting and lazy loading
- CDN delivery via Vercel
- Optimized bundle size

## 🐛 Troubleshooting

### Common Issues
- **Build fails**: Check environment variables and dependencies
- **Payments not working**: Verify Stripe API keys and webhook configuration
- **Emails not sending**: Check Resend API key and domain verification
- **Authentication issues**: Verify Clerk configuration and allowed domains

### Getting Help
- Check the deployment guide
- Review environment variable configuration
- Check browser console for errors
- Verify API service configurations

## 📝 License

This project is proprietary software for Range Breakout Pro EA.

## 🤝 Support

For technical support or questions about the landing page:
- Check the documentation files
- Review the troubleshooting section
- Contact the development team

---

**Built with ❤️ for Range Breakout Pro EA**

Ready to launch your presale campaign and start converting visitors into customers! 🚀

